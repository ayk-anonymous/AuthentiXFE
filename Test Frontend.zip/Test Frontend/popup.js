document.addEventListener('DOMContentLoaded', function () {
  // Popup references
  const firstPopup = document.getElementById('first-popup');
  const secondPopup = document.getElementById('second-popup');
  const thirdPopup = document.getElementById('third-popup');
  
  // Button and field references
  const uploadArea = document.getElementById('upload-area');
  const imageUpload = document.getElementById('image-upload');
  const predictButton = document.getElementById('predict-button');
  const proceedButton = document.getElementById('proceed-button');
  const predictAgainButton = document.getElementById('predict-again-button'); // Reference to the "Predict Again" button
  const uploadIcon = document.getElementById('upload-icon');
  const fields = document.querySelectorAll('.field-value');

  // Handle file upload via drag and drop
  uploadArea.addEventListener('dragover', (event) => {
    event.preventDefault();
    uploadArea.classList.add('hover');
  });

  uploadArea.addEventListener('dragleave', () => {
    uploadArea.classList.remove('hover');
  });

  uploadArea.addEventListener('drop', (event) => {
    event.preventDefault();
    uploadArea.classList.remove('hover');
    const file = event.dataTransfer.files[0];
    handleFileUpload(file);
  });

  // Handle file upload via file input
  imageUpload.addEventListener('change', () => {
    const file = imageUpload.files[0];
    handleFileUpload(file);
  });

  // Handle upload icon click
  uploadIcon.addEventListener('click', () => {
    imageUpload.click();
  });

  // Handle file upload
  function handleFileUpload(file) {
    if (file && file.type.startsWith('image/')) {
      console.log('File uploaded:', file);
      // Hide the first popup and show the second popup
      firstPopup.style.display = 'none';
      secondPopup.style.display = 'block';
    } else {
      alert('Please upload a valid image file.');
    }
  }

  // Predict button click - shows the second popup
  predictButton.addEventListener('click', () => {
    firstPopup.style.display = 'none';
    secondPopup.style.display = 'block';
  });

  // Proceed button click - shows the third popup
  proceedButton.addEventListener('click', () => {
    secondPopup.style.display = 'none';
    thirdPopup.style.display = 'block';

    // Sample accuracy data - this would be dynamically set based on actual prediction results
    const accuracyPercentage = 86.4; // Example accuracy

    // Update circular progress background based on accuracy
    const circularProgress = document.querySelector('.circular-progress');
    circularProgress.style.background = `conic-gradient(#b19cd9 0% ${accuracyPercentage}%, #4b4b74 ${accuracyPercentage}% 100%)`;

    // Display accuracy inside circular progress bar
    const accuracyText = document.querySelector('.accuracy-percentage');
    accuracyText.textContent = `${accuracyPercentage}%`;

    // Collect and log validated data from the second popup (optional)
    const data = {};
    fields.forEach(field => {
      const id = field.getAttribute('id');
      const value = field.textContent.trim();
      data[id] = value;
    });
    console.log("Validated data:", data);
  });

  // "Predict Again" button click - goes back to the first popup
  predictAgainButton.addEventListener('click', () => {
    // Hide the third popup and show the first popup
    thirdPopup.style.display = 'none';
    firstPopup.style.display = 'block';

    // Optionally, reset fields or any specific data here
    fields.forEach(field => {
      field.textContent = '0'; // Reset each field to '0' or initial value
    });

    // Clear any uploaded files if needed (optional)
    imageUpload.value = '';
    console.log("Reset to initial state.");
  });

  // Make each field editable and validate input (optional)
  fields.forEach(field => {
    field.addEventListener('input', (event) => {
      // Only allow numbers (optional validation)
      event.target.textContent = event.target.textContent.replace(/[^0-9]/g, '');
    });
  });
});
